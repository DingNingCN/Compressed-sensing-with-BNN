import torch
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from utils import Data, CS
from BCSNET.model import BCSNet
import warnings
warnings.filterwarnings("ignore")
import argparse

from torch import nn
import os

from loss import *
from trainer import *

parser = argparse.ArgumentParser()
parser.add_argument('--model', type=str, default='binarized_rkccsnet',
                    choices=['csnet', 'rkccsnet'],
                    help='choose model to train')
#defult=0.50000
parser.add_argument('--sensing-rate', type=float, default=0.05,
                    choices=[0.50000, 0.25000, 0.12500, 0.06250, 0.03125],
                    help='set sensing rate')
parser.add_argument('--epochs', default=25, type=int, metavar='N',
                    help='number of total epochs to run')
parser.add_argument('-b', '--batch-size', default=4, type=int,
                    metavar='N', help='mini-batch size (default: 128)')
parser.add_argument('--block-size', default=64, type=int,
                    metavar='N', help='block size (default: 32)')
parser.add_argument('--image-size', default=50, type=int,
                    metavar='N', help='image size used for training (default: 96)')
parser.add_argument('--lr', '--learning-rate', default=5e-4 , type=float,
                    metavar='LR', help='initial learning rate')
parser.add_argument('--save-dir', dest='save_dir',
                    help='The directory used to save the trained models',
                    default='pth', type=str)

'''如何设置单元格，只需要输入 # %% 就可以了'''

args = parser.parse_args()

model = BCSNet(sensing_rate=args.sensing_rate)
criterion = loss_fn
# criterion = nn.MSELoss()
if torch.cuda.is_available():
    model.cuda()
    # criterion.cuda()
    print('GPU is available')

optimizer = optim.Adam(model.parameters(), lr=args.lr, betas=(0.9, 0.999))
scheduler = optim.lr_scheduler.MultiStepLR(optimizer, [60, 90, 120, 150, 180], gamma=0.25, last_epoch=-1)

d = Data()

train_loader = d.importData('train')
valid_loader = d.importData('test')
N = 256
train_loader = d.splitData(train_loader, N)
valid_loader = d.splitData(valid_loader, N)
train_loader = train_loader.astype(np.float32)
valid_loader = valid_loader.astype(np.float32)

train_loader = torch.from_numpy(train_loader)
train_loader = torch.unsqueeze(train_loader, 1)
train_loader = torch.unsqueeze(train_loader, 1)
valid_loader = torch.from_numpy(valid_loader)
valid_loader = torch.unsqueeze(valid_loader, 1)
valid_loader = torch.unsqueeze(valid_loader, 1)  #这6行代码是把数据转成50781*1*1*256的张量

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
train_loader = train_loader.to(device)
valid_loader = valid_loader.to(device)
#train_loader = train_loader.type(torch.cuda.FloatTensor)
#valid_loader = valid_loader.type(torch.cuda.FloatTensor)

print('---------------------')
print ('train_loader size:', train_loader.shape)  #每一个103，104，105对应的数据是65000个值，所以这里38个作为训练集，共有65000*38个值，刚好是96484*256个
print ('valid_loader size:', valid_loader.shape)
print('---------------------')
print('\nModel: %s\n'
        'Sensing Rate: %.2f\n'
        'Epoch: %d\n'
        'Initial LR: %f\n'
        % (args.model, args.sensing_rate, args.epochs, args.lr))
print('Start training')
doc = open("result_binary_final.txt", 'w+')  #创建一个记事本来记录训练信息

#train_dataset = TensorDataset(train_loader)
#valid_dataset = TensorDataset(valid_loader)


#train_loader = DataLoader(dataset=train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)
#valid_loader = DataLoader(dataset=train_dataset, batch_size=args.batch_size, shuffle=True, num_workers=0)
# train_loader = torch.split(train_loader, args.batch_size, dim=0)
# valid_loader = torch.split(valid_loader, args.batch_size, dim=0)

doc = open("result.txt", 'w+')
for epoch in range(args.epochs):

    print('\ncurrent lr {:.5e}'.format(optimizer.param_groups[0]['lr']),file=doc)
    

    loss = train(train_loader, model, criterion, optimizer, epoch,doc)
    print('\ncurrent loss {:.5e}'.format(loss),file=doc)
    scheduler.step()
    if (epoch+1)%5==0 or epoch==199:
        psnr,prd= valid(valid_loader, model, criterion)
        print("Total Loss: %f" % loss,file=doc)
        print("Total Loss: %f" % loss)
        print("PSNR: %f" % psnr,file=doc)
        print("PSNR: %f" % psnr)
        print("PRD: %f" % prd,file=doc)
        print("PRD: %f" % prd)
    print("Total Loss: %f" % loss)

    # for saving model
    save_dir = 'epochs' + '_subrate_' + str(args.sensing_rate) + '_blocksize_' + str(args.block_size) + '_resnet_binary_final'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    if epoch % 1 == 0:
        torch.save(model.state_dict(), save_dir + '/net_epoch_%d_%6f.pth' % (epoch, loss))
print('Trained finished.')
print('Model saved in %s' % (os.path.join(args.save_dir, args.model+'.pth')))


input0=valid_loader[1]
input1 = torch.from_numpy(
    (input0.cpu().numpy() - np.min(input0.cpu().numpy())) / (np.max(input0.cpu().numpy()) - np.min(input0.cpu().numpy()))).cuda()

output0 = model(input1)

input0=valid_loader[1].cpu().numpy().reshape(256)

plt.plot(range(256),input0,'r',range(256),output0[0].cpu().detach().reshape(256)*(np.max(input0) - np.min(input0)) + np.min(input0),'b')
plt.show()
plt.savefig('result.png', dpi=200)
