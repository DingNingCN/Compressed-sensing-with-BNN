import argparse
import torch
from torch.autograd import Variable
import numpy as np
import time, math, glob
import scipy.io as sio
from BCSNET.model import BCSNet
import matplotlib.pyplot as plt
from utils import Data
from trainer import *

parser = argparse.ArgumentParser(description="PyTorch LapSRN Eval")
# parser.add_argument("--cuda", action="store_true", help="use cuda?")
parser.add_argument("--cuda", default="True", help="use cuda?")
parser.add_argument("--model", default="epochs_subrate_0.05_blocksize_8_resnet_binarized_withbn16_withoutrelu/net_epoch_16_0.002156.pth", type=str, help="model path")
parser.add_argument("--dataset", default="Test/Set5_mat", type=str, help="dataset name, Default: Set5")
parser.add_argument('--block_size', default=8, type=int, help='CS block size')
parser.add_argument('--sub_rate', default=0.1, type=float, help='sampling sub rate')
parser.add_argument('--sensing-rate', type=float, default=0.05,
                    choices=[0.50000, 0.25000, 0.12500, 0.06250, 0.03125],
                    help='set sensing rate')
args = parser.parse_args()

d = Data()

train_loader = d.importData('train')
valid_loader = d.importData('test')
N = 256
train_loader = d.splitData(train_loader, N)
valid_loader = d.splitData(valid_loader, N)

train_loader = torch.from_numpy(train_loader)
train_loader = torch.unsqueeze(train_loader, 1)
train_loader = torch.unsqueeze(train_loader, 1)
valid_loader = torch.from_numpy(valid_loader)
valid_loader = torch.unsqueeze(valid_loader, 1)
valid_loader = torch.unsqueeze(valid_loader, 1)  #这6行代码是把数据转成50781*1*1*256的张量, 因为Conv1d是batchsize*chanel*长度的，只有三维

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
train_loader = train_loader.to(device)
valid_loader = valid_loader.to(device)
train_loader = train_loader.type(torch.cuda.FloatTensor)
valid_loader = valid_loader.type(torch.cuda.FloatTensor)

model = BCSNet(sensing_rate=args.sensing_rate)

if torch.cuda.is_available():
    model.cuda()
    print('GPU is available')

if args.model != '':
    model.load_state_dict(torch.load(args.model))

input0 = valid_loader[9998]
input1 = valid_loader[9999]
input2 = valid_loader[10000]
input3 = valid_loader[10001]

input00 = torch.from_numpy(
    (input0.cpu().numpy() - np.min(input0.cpu().numpy())) / (np.max(input0.cpu().numpy()) - np.min(input0.cpu().numpy()))).cuda()
input10 = torch.from_numpy(
    (input1.cpu().numpy() - np.min(input1.cpu().numpy())) / (np.max(input1.cpu().numpy()) - np.min(input1.cpu().numpy()))).cuda()
input20 = torch.from_numpy(
    (input2.cpu().numpy() - np.min(input2.cpu().numpy())) / (np.max(input2.cpu().numpy()) - np.min(input2.cpu().numpy()))).cuda()
input30 = torch.from_numpy(
    (input3.cpu().numpy() - np.min(input3.cpu().numpy())) / (np.max(input3.cpu().numpy()) - np.min(input3.cpu().numpy()))).cuda()

output0 = model(input00)
output1 = model(input10)
output2 = model(input20)
output3 = model(input30)

input0=input0.cpu().numpy().reshape(256)
input1=input1.cpu().numpy().reshape(256)
input2=input2.cpu().numpy().reshape(256)
input3=input3.cpu().numpy().reshape(256)

output0 = output0[0].cpu().detach().reshape(256) *(np.max(input0) - np.min(input0)) + np.min(input0)
output1 = output1[0].cpu().detach().reshape(256) *(np.max(input1) - np.min(input1)) + np.min(input1)
output2 = output2[0].cpu().detach().reshape(256) *(np.max(input2) - np.min(input2)) + np.min(input2)
output3 = output3[0].cpu().detach().reshape(256) *(np.max(input3) - np.min(input3)) + np.min(input3)



combined_input = np.concatenate((input0,input1,input2,input3))
combined_output = np.concatenate((output0,output1,output2,output3))

print('input0shape:', combined_input.shape)

def calculate_prd(input_signal, output_signal):
    sum_squared_diff = np.sum((input_signal - output_signal) ** 2)
    sum_squared_input = np.sum(input_signal ** 2)
    prd = np.sqrt(sum_squared_diff / sum_squared_input) * 100
    return prd

def calculate_snr(input_signal, output_signal):
    signal_power = np.sum(input_signal ** 2)
    noise_power = np.sum((input_signal - output_signal) ** 2)
    snr = 10 * np.log10(signal_power / noise_power)
    return snr

prd_value = calculate_prd(combined_input, combined_output)
snr_value = calculate_snr(combined_input, combined_output)
print(f"PRD: {prd_value:.4f}%")
print(f"SNR: {snr_value:.2f} dB")


plt.plot(range(1024), combined_input, 'r', label='GT Input')
plt.plot(range(1024), combined_output, 'b', label='Output')
# Add legend in the upper right corner
plt.legend(loc='upper right')
plt.title(f"PRD: {prd_value:.4f}%, SNR: {snr_value:.2f} dB")
plt.show()

# plt.savefig('result.png', dpi=200)

#print(valid_loader.shape)