from .compressed_sensing import CS
from .data import Data