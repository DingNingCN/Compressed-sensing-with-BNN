from utils import *
from matplotlib import pyplot as plt
import sys
import argparse
import torch
import numpy as np
# import _ssim
ber_matrix=np.random.choice([-1,1],(25,256))/np.sqrt(25)
ber_matrix=np.random.randn(25,256)
#model1=torch.load('.\\pth\\model_199.pth')
def prdcal(inputs,outputs):
    n,c,x=inputs.shape
    sum1=0
    sum2=0
    for i in range(x):
            sum1=sum1+(inputs[0,0,i]-outputs[0,0,i])*(inputs[0,0,i]-outputs[0,0,i])
            sum2=sum2+(inputs[0,0,i])*(inputs[0,0,i])
    prd=np.sqrt((sum1/sum2).cpu())*100 #这是一段信号的prd，而且是乘了100的
    snr=10*np.log10(sum2.cpu()/sum1.cpu()) #这里把sum2当作了信号的能量，把sum1也就是残差的平方当作了噪声的功率

    return prd,snr
def train(train_loader, model, criterion, optimizer, epoch,doc):
    print('Epoch: %d' % (epoch + 1),file=doc)
    print('mine-5 Epoch: %d' % (epoch + 1))
    model.train()
    sum_loss = 0
    t=0
    for inputs in train_loader:#1,1,256
        # print(inputs.shape)
        #inputs = inputs[0]#每一个input[0]都是一个4*1*256的tensor
        original=inputs
        #inputs = rgb_to_ycbcr(inputs)[:, 0, :, :].unsqueeze(1) / 255.
        inputs = torch.from_numpy((inputs.cpu().numpy() - np.min(inputs.cpu().numpy())) / (np.max(inputs.cpu().numpy())-np.min(inputs.cpu().numpy()))).cuda()
        # print('input1size:', inputs.shape)
        optimizer.zero_grad()
        outputs = model(inputs)
        #loss = criterion(outputs[0], inputs) + criterion(outputs[1], inputs) + criterion(outputs[2], inputs)
        loss = criterion(outputs[0], inputs)
        loss.backward()
        optimizer.step()
        sum_loss += loss.item()
        t=t+1
        if (t%10000==0):
            print(str(t)+'/50000') #一共50000个样本


    return sum_loss/t #t最大也就50000/4而已，这个train的意思是，把一个batch里的数据都遍历一遍，得到总的loss，返回值是loss/256，也就是一个1*1*256的信号的loss


def valid(valid_loader, model, criterion):
    sum_snr = 0
    sum_ssim = 0
    sum_prd = 0
    # _ssim = SSIM().cuda()
    model.eval() #关闭梯度的运算，以及关闭dropout的单元和batchnorm的单元
    with torch.no_grad():
        s=0
        for iters, (inputs) in enumerate(valid_loader):
            #inputs = inputs[0]
            original=inputs
            #inputs = rgb_to_ycbcr(inputs)[:, 0, :, :].unsqueeze(1) / 255.
            inputs = torch.from_numpy((inputs.cpu().numpy() - np.min(inputs.cpu().numpy())) / (np.max(inputs.cpu().numpy()) - np.min(inputs.cpu().numpy()))).cuda()
            outputs = model(inputs)
            outputs=outputs[0]*(np.max(original.cpu().numpy()) - np.min(original.cpu().numpy())) + np.min(original.cpu().numpy())
            prd,snr=prdcal(original,outputs) #这里的prd是百分比相对偏差
            sum_prd += prd
            sum_snr += snr #sum_snr是整个验证集的加和
            s=s+1
            if (s % 4000 == 0):
                print(str(round(s/12000*100,2))+'%') #这个是打印验证时的进度，由于一共只有12000左右，所以4000，8000，12000来除以它，分别得到33%66%和100%
                #而把batch改成4之后，验证集只有3000多个batch了

    return sum_snr / (iters), sum_prd/(iters)

'''
def test(test_loader, model, criterion):
    sum_psnr = 0
    sum_ssim = 0
    _ssim = SSIM()
    model.test()
    with torch.no_grad():
        for iters, (inputs, _) in enumerate(test_loader):
            inputs = rgb_to_ycbcr(inputs)[:, 0, :, :].unsqueeze(1) / 255.
            outputs = model(inputs)
            mse = F.mse_loss(outputs[0], inputs)
            psnr = 10 * log10(1 / mse.item())
            sum_psnr += psnr
            sum_ssim += ssim(outputs[0], inputs)
    return sum_psnr / (iters), sum_ssim / (iters)
'''

